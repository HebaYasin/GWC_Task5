UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'ENGAGED', 
    first_response_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'farooque.vala@gwclogistics.com',
    detected_working_rep_name = 'Farooque Abdulkarimabdul Vala',
    status_history = '[{"status":"ENGAGED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-761040871613' AND current_status != 'ENGAGED';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'ENGAGED', 
    first_response_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'mohammed.razak@gwclogistics.com',
    detected_working_rep_name = 'Mohammed Razak',
    status_history = '[{"status":"ENGAGED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-761325693138' AND current_status != 'ENGAGED';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'ENGAGED', 
    first_response_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'mubashar.ahmad@gwclogistics.com',
    detected_working_rep_name = 'Mubashar Nazir Ahmad',
    status_history = '[{"status":"ENGAGED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-761532034294' AND current_status != 'ENGAGED';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'ENGAGED', 
    first_response_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'mohammed.razak@gwclogistics.com',
    detected_working_rep_name = 'Mohammed Razak',
    status_history = '[{"status":"ENGAGED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-761574957246' AND current_status != 'ENGAGED';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'ENGAGED', 
    first_response_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'mohammed.razak@gwclogistics.com',
    detected_working_rep_name = 'Mohammed Razak',
    status_history = '[{"status":"ENGAGED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-761877031123' AND current_status != 'ENGAGED';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'ENGAGED', 
    first_response_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'husam.shakhshir@gwclogistics.com',
    detected_working_rep_name = 'Husam Ramzi Shakhshir',
    status_history = '[{"status":"ENGAGED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-762298310882' AND current_status != 'ENGAGED';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'ENGAGED', 
    first_response_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'mourad.kachbouri@gwclogistics.com',
    detected_working_rep_name = 'Mourad Kachbouri',
    status_history = '[{"status":"ENGAGED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-762335312104' AND current_status != 'ENGAGED';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'ENGAGED', 
    first_response_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'mohammed.razak@gwclogistics.com',
    detected_working_rep_name = 'Mohammed Razak',
    status_history = '[{"status":"ENGAGED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-762433264878' AND current_status != 'ENGAGED'
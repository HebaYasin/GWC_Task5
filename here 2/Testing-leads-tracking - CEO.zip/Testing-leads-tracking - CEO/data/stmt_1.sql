MERGE INTO claude_prototyping.marketing.leads_maturity AS target
USING (
  SELECT 'GWC-762463488209' AS gwc_id, 'USA' AS assigned_country, 'nil | UNROUTABLE: No sales rep configured for country: \'USA\' (Quip: \'\', email to_country: \'USA\', canonical: \'USA\')' AS notes, '2026-04-23T06:38:34Z' AS updated_at
  UNION ALL SELECT 'GWC-763009524937' AS gwc_id, 'Tanzania' AS assigned_country, 'Canon printer machine 100kg | UNROUTABLE: No sales rep configured for country: \'Tanzania\' (Quip: \'\', email to_country: \'Tanzania\', canonical: \'Tanzania\')' AS notes, '2026-04-23T06:38:35Z' AS updated_at
) AS source
ON target.gwc_id = source.gwc_id
WHEN MATCHED THEN UPDATE SET target.assigned_country = source.assigned_country, target.notes = source.notes, target.updated_at = source.updated_at
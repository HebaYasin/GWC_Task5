INSERT INTO claude_prototyping.marketing.leads_maturity 
(id, gwc_id, email_message_id, notes, classification, missing_fields, current_status, 
 status_history, assigned_rep_email, assigned_rep_name, email_received_at, 
 first_response_at, quote_sent_at, follow_up_started_at, detected_working_rep_email,
 detected_working_rep_name, bd_poc_email, bd_poc_name, created_at, updated_at, last_email_scan_at)
SELECT '278', 'GWC-745239655649', 'AAMkADA1MjY1NTZhLTEzNzQtNDkzYS1iYmExLTc1ZTA4MDBlMTEyZgBGAAAAAAAAZTsS5yqSRpnCGmQKSXhABwALBAXNdhs-R4Ju6eUoohT6AAAAAAEMAAALBAXNdhs-R4Ju6eUoohT6AAAJ08xUAAA=',
       '[BACKFILLED 2026-04-23] Pre-pipeline lead. Original HubSpot email received before 2026-04-08 (pipeline start). Status assigned by AI analysis of email thread. Structural fields (origin, product, weight etc.) unknown — retrieve from HubSpot if required. | AI-classified 2026-04-23: QUOTED (high confidence) | AI-classified 2026-04-23: QUOTED (high confidence)', 'PRE_PIPELINE', array(),
       'QUOTED', '[{"status": "QUOTED", "timestamp": "2026-04-23T06:54:27Z", "changed_by": "SYSTEM", "reason": "Qusai Alattiyat sent ''quotation details are re...'' to customer (Apr 9).", "confidence": "high", "evidence": "RFQ #FFD/S/260423758 - quotation sent"}]',
       'qusai.alattiyat@gwclogistics.com', 'Qusai Nael Abdulkareem Alattiyat',
       '2026-04-09T06:21:48Z',
       NULL, '2026-04-23T06:54:27Z',
       NULL,
       'qusai.alattiyat@gwclogistics.com', 'Qusai Nael Abdulkareem Alattiyat',
       'qusai.alattiyat@gwclogistics.com', 'Qusai Nael Abdulkareem Alattiyat',
       '2026-04-23T06:54:28Z', '2026-04-23T06:57:22Z', '2026-04-23T06:57:18Z'
WHERE NOT EXISTS (SELECT 1 FROM claude_prototyping.marketing.leads_maturity WHERE gwc_id = 'GWC-745239655649')
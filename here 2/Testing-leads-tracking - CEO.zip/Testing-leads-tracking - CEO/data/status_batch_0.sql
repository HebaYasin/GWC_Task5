UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'FOLLOW_UP', 
    follow_up_started_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'asra.saifulah@gwclogistics.com',
    detected_working_rep_name = 'Asra Syed Saifulah',
    status_history = '[{"status":"FOLLOW_UP","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-727648243902' AND current_status != 'FOLLOW_UP';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'FOLLOW_UP', 
    follow_up_started_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'farooque.vala@gwclogistics.com',
    detected_working_rep_name = 'Farooque Abdulkarimabdul Vala',
    status_history = '[{"status":"FOLLOW_UP","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-733185949909' AND current_status != 'FOLLOW_UP';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'ENGAGED', 
    first_response_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'farooque.vala@gwclogistics.com',
    detected_working_rep_name = 'Farooque Abdulkarimabdul Vala',
    status_history = '[{"status":"ENGAGED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-733975782624' AND current_status != 'ENGAGED';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'QUOTED', 
    quote_sent_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'mohammed.rizwan@gwclogistics.com',
    detected_working_rep_name = 'Mohammed Rizwan',
    status_history = '[{"status":"QUOTED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-741341587696' AND current_status != 'QUOTED';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'QUOTED', 
    quote_sent_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'farooque.vala@gwclogistics.com',
    detected_working_rep_name = 'Farooque Abdulkarimabdul Vala',
    status_history = '[{"status":"QUOTED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-741397943508' AND current_status != 'QUOTED';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'QUOTED', 
    quote_sent_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'farooque.vala@gwclogistics.com',
    detected_working_rep_name = 'Farooque Abdulkarimabdul Vala',
    status_history = '[{"status":"QUOTED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-743692672224' AND current_status != 'QUOTED';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'ENGAGED', 
    first_response_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'mourad.kachbouri@gwclogistics.com',
    detected_working_rep_name = 'Mourad Kachbouri',
    status_history = '[{"status":"ENGAGED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-752250524869' AND current_status != 'ENGAGED';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'QUOTED', 
    quote_sent_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'farooque.vala@gwclogistics.com',
    detected_working_rep_name = 'Farooque Abdulkarimabdul Vala',
    status_history = '[{"status":"QUOTED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-752256184563' AND current_status != 'QUOTED';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'QUOTED', 
    quote_sent_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'farooque.vala@gwclogistics.com',
    detected_working_rep_name = 'Farooque Abdulkarimabdul Vala',
    status_history = '[{"status":"QUOTED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-752257541324' AND current_status != 'QUOTED';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'ENGAGED', 
    first_response_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'mourad.kachbouri@gwclogistics.com',
    detected_working_rep_name = 'Mourad Kachbouri',
    status_history = '[{"status":"ENGAGED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-754220946623' AND current_status != 'ENGAGED';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'ENGAGED', 
    first_response_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'mohammed.razak@gwclogistics.com',
    detected_working_rep_name = 'Mohammed Razak',
    status_history = '[{"status":"ENGAGED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-754854918338' AND current_status != 'ENGAGED';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'QUOTED', 
    quote_sent_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'farooque.vala@gwclogistics.com',
    detected_working_rep_name = 'Farooque Abdulkarimabdul Vala',
    status_history = '[{"status":"QUOTED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-756173197524' AND current_status != 'QUOTED';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'FOLLOW_UP', 
    follow_up_started_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'mahesh.muralidharan@gwclogistics.com',
    detected_working_rep_name = 'Mahesh Muralidharan',
    status_history = '[{"status":"FOLLOW_UP","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-756241233119' AND current_status != 'FOLLOW_UP';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'ENGAGED', 
    first_response_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'farooque.vala@gwclogistics.com',
    detected_working_rep_name = 'Farooque Abdulkarimabdul Vala',
    status_history = '[{"status":"ENGAGED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-757023510743' AND current_status != 'ENGAGED';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'ENGAGED', 
    first_response_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'farooque.vala@gwclogistics.com',
    detected_working_rep_name = 'Farooque Abdulkarimabdul Vala',
    status_history = '[{"status":"ENGAGED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-757360549106' AND current_status != 'ENGAGED'
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'QUOTED', 
    quote_sent_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'mohammed.rizwan@gwclogistics.com',
    detected_working_rep_name = 'Mohammed Rizwan',
    status_history = '[{"status":"QUOTED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-757370040563' AND current_status != 'QUOTED';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'QUOTED', 
    quote_sent_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'farooque.vala@gwclogistics.com',
    detected_working_rep_name = 'Farooque Abdulkarimabdul Vala',
    status_history = '[{"status":"QUOTED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-757373418719' AND current_status != 'QUOTED';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'ENGAGED', 
    first_response_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'farooque.vala@gwclogistics.com',
    detected_working_rep_name = 'Farooque Abdulkarimabdul Vala',
    status_history = '[{"status":"ENGAGED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-757541267661' AND current_status != 'ENGAGED';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'ENGAGED', 
    first_response_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'farooque.vala@gwclogistics.com',
    detected_working_rep_name = 'Farooque Abdulkarimabdul Vala',
    status_history = '[{"status":"ENGAGED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-757550536919' AND current_status != 'ENGAGED';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'FOLLOW_UP', 
    follow_up_started_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'farooque.vala@gwclogistics.com',
    detected_working_rep_name = 'Farooque Abdulkarimabdul Vala',
    status_history = '[{"status":"FOLLOW_UP","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-758109615296' AND current_status != 'FOLLOW_UP';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'ENGAGED', 
    first_response_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'farooque.vala@gwclogistics.com',
    detected_working_rep_name = 'Farooque Abdulkarimabdul Vala',
    status_history = '[{"status":"ENGAGED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-758453612792' AND current_status != 'ENGAGED';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'ENGAGED', 
    first_response_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'farooque.vala@gwclogistics.com',
    detected_working_rep_name = 'Farooque Abdulkarimabdul Vala',
    status_history = '[{"status":"ENGAGED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-758457769156' AND current_status != 'ENGAGED';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'ENGAGED', 
    first_response_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'farooque.vala@gwclogistics.com',
    detected_working_rep_name = 'Farooque Abdulkarimabdul Vala',
    status_history = '[{"status":"ENGAGED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-758514783461' AND current_status != 'ENGAGED';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'ENGAGED', 
    first_response_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'farooque.vala@gwclogistics.com',
    detected_working_rep_name = 'Farooque Abdulkarimabdul Vala',
    status_history = '[{"status":"ENGAGED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-758839436512' AND current_status != 'ENGAGED';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'ENGAGED', 
    first_response_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'farooque.vala@gwclogistics.com',
    detected_working_rep_name = 'Farooque Abdulkarimabdul Vala',
    status_history = '[{"status":"ENGAGED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-758903611616' AND current_status != 'ENGAGED';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'ENGAGED', 
    first_response_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'farooque.vala@gwclogistics.com',
    detected_working_rep_name = 'Farooque Abdulkarimabdul Vala',
    status_history = '[{"status":"ENGAGED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-759151909064' AND current_status != 'ENGAGED';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'ENGAGED', 
    first_response_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'mourad.kachbouri@gwclogistics.com',
    detected_working_rep_name = 'Mourad Kachbouri',
    status_history = '[{"status":"ENGAGED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-759179857129' AND current_status != 'ENGAGED';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'ENGAGED', 
    first_response_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'mohammed.razak@gwclogistics.com',
    detected_working_rep_name = 'Mohammed Razak',
    status_history = '[{"status":"ENGAGED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-759689038020' AND current_status != 'ENGAGED';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'ENGAGED', 
    first_response_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'mirza.baig@gwclogistics.com',
    detected_working_rep_name = 'Mirza Ibad Baig',
    status_history = '[{"status":"ENGAGED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-760593515766' AND current_status != 'ENGAGED';
UPDATE claude_prototyping.marketing.leads_maturity 
SET current_status = 'ENGAGED', 
    first_response_at = '2026-04-23T06:57:18Z',
    last_email_scan_at = '2026-04-23T07:00:00Z',
    detected_working_rep_email = 'mohammed.razak@gwclogistics.com',
    detected_working_rep_name = 'Mohammed Razak',
    status_history = '[{"status":"ENGAGED","timestamp":"2026-04-23T06:57:18Z","changed_by":"SYSTEM","confidence":"high"}]',
    updated_at = '2026-04-23T07:00:00Z'
WHERE gwc_id = 'GWC-760905446625' AND current_status != 'ENGAGED'
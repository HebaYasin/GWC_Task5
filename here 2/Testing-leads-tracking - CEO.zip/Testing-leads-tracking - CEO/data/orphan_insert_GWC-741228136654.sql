INSERT INTO claude_prototyping.marketing.leads_maturity 
(id, gwc_id, email_message_id, notes, classification, missing_fields, current_status, 
 status_history, assigned_rep_email, assigned_rep_name, email_received_at, 
 first_response_at, quote_sent_at, follow_up_started_at, detected_working_rep_email,
 detected_working_rep_name, bd_poc_email, bd_poc_name, created_at, updated_at, last_email_scan_at)
SELECT '277', 'GWC-741228136654', 'AAMkADA1MjY1NTZhLTEzNzQtNDkzYS1iYmExLTc1ZTA4MDBlMTEyZgBGAAAAAAAAZTsS5yqSRpnCGmQKSXhABwALBAXNdhs-R4Ju6eUoohT6AAAAAAEMAAALBAXNdhs-R4Ju6eUoohT6AAAJ08xLAAA=',
       '[BACKFILLED 2026-04-23] Pre-pipeline lead. Original HubSpot email received before 2026-04-08 (pipeline start). Status assigned by AI analysis of email thread. Structural fields (origin, product, weight etc.) unknown — retrieve from HubSpot if required. | AI-classified 2026-04-23: NO_ACTION (high confidence)', 'PRE_PIPELINE', array(),
       'NO_ACTION', '[]',
       'jakub.skopec@gwclogistics.com', 'Jakub Skopec GWC',
       '2026-04-07T13:55:21Z',
       NULL, NULL,
       NULL,
       NULL, NULL,
       NULL, NULL,
       '2026-04-23T06:54:28Z', '2026-04-23T06:58:14Z', '2026-04-23T06:57:18Z'
WHERE NOT EXISTS (SELECT 1 FROM claude_prototyping.marketing.leads_maturity WHERE gwc_id = 'GWC-741228136654')
INSERT INTO claude_prototyping.marketing.leads_maturity 
(id, gwc_id, email_message_id, notes, classification, missing_fields, current_status, 
 status_history, assigned_rep_email, assigned_rep_name, email_received_at, 
 first_response_at, quote_sent_at, follow_up_started_at, detected_working_rep_email,
 detected_working_rep_name, bd_poc_email, bd_poc_name, created_at, updated_at, last_email_scan_at)
SELECT '287', 'GWC-758379950306', 'AAMkADA1MjY1NTZhLTEzNzQtNDkzYS1iYmExLTc1ZTA4MDBlMTEyZgBGAAAAAAAAZTsS5yqSRpnCGmQKSXhABwALBAXNdhs-R4Ju6eUoohT6AAAAAAEMAAALBAXNdhs-R4Ju6eUoohT6AAAU3gsoAAA=',
       '[BACKFILLED 2026-04-23] Pre-pipeline lead. Original HubSpot email received before 2026-04-08 (pipeline start). Status assigned by AI analysis of email thread. Structural fields (origin, product, weight etc.) unknown — retrieve from HubSpot if required. | AI-classified 2026-04-23: ENGAGED (medium confidence) | AI-classified 2026-04-23: ENGAGED (medium confidence)', 'PRE_PIPELINE', array(),
       'ENGAGED', '[{"status": "ENGAGED", "timestamp": "2026-04-23T06:54:27Z", "changed_by": "SYSTEM", "reason": "Farooque sent kind reminder + external customer reply visible (Apr 19-22). Rep actively engaged, no quote yet.", "confidence": "medium", "evidence": "Farooque: ''Kind reminder\u2026Please provide below requested details''; customer email reply seen"}]',
       'farooque.vala@gwclogistics.com', 'Farooque Abdulkarimabdul Vala',
       '2026-04-19T06:52:25Z',
       '2026-04-23T06:54:27Z', NULL,
       NULL,
       'mohammed.rizwan@gwclogistics.com', 'Mohammed Rizwan',
       'mohammed.rizwan@gwclogistics.com', 'Mohammed Rizwan',
       '2026-04-23T06:54:32Z', '2026-04-23T06:57:31Z', '2026-04-23T06:57:18Z'
WHERE NOT EXISTS (SELECT 1 FROM claude_prototyping.marketing.leads_maturity WHERE gwc_id = 'GWC-758379950306')
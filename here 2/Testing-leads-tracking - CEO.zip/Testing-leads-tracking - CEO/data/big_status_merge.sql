MERGE INTO claude_prototyping.marketing.leads_maturity AS target
USING (
  SELECT 'GWC-727648243902' AS gwc_id, 'FOLLOW_UP' AS new_status, 'follow_up_started_at' AS ts_field, 'asra.saifulah@gwclogistics.com' AS rep_email, 'Asra Syed Saifulah' AS rep_name
  UNION ALL
  SELECT 'GWC-733975782624' AS gwc_id, 'ENGAGED' AS new_status, 'first_response_at' AS ts_field, 'farooque.vala@gwclogistics.com' AS rep_email, 'Farooque Abdulkarimabdul Vala' AS rep_name
  UNION ALL
  SELECT 'GWC-741341587696' AS gwc_id, 'QUOTED' AS new_status, 'quote_sent_at' AS ts_field, 'mohammed.rizwan@gwclogistics.com' AS rep_email, 'Mohammed Rizwan' AS rep_name
  UNION ALL
  SELECT 'GWC-741397943508' AS gwc_id, 'QUOTED' AS new_status, 'quote_sent_at' AS ts_field, 'farooque.vala@gwclogistics.com' AS rep_email, 'Farooque Abdulkarimabdul Vala' AS rep_name
  UNION ALL
  SELECT 'GWC-743692672224' AS gwc_id, 'QUOTED' AS new_status, 'quote_sent_at' AS ts_field, 'farooque.vala@gwclogistics.com' AS rep_email, 'Farooque Abdulkarimabdul Vala' AS rep_name
  UNION ALL
  SELECT 'GWC-752250524869' AS gwc_id, 'ENGAGED' AS new_status, 'first_response_at' AS ts_field, 'mourad.kachbouri@gwclogistics.com' AS rep_email, 'Mourad Kachbouri' AS rep_name
  UNION ALL
  SELECT 'GWC-752256184563' AS gwc_id, 'QUOTED' AS new_status, 'quote_sent_at' AS ts_field, 'farooque.vala@gwclogistics.com' AS rep_email, 'Farooque Abdulkarimabdul Vala' AS rep_name
  UNION ALL
  SELECT 'GWC-752257541324' AS gwc_id, 'QUOTED' AS new_status, 'quote_sent_at' AS ts_field, 'farooque.vala@gwclogistics.com' AS rep_email, 'Farooque Abdulkarimabdul Vala' AS rep_name
  UNION ALL
  SELECT 'GWC-754220946623' AS gwc_id, 'ENGAGED' AS new_status, 'first_response_at' AS ts_field, 'mourad.kachbouri@gwclogistics.com' AS rep_email, 'Mourad Kachbouri' AS rep_name
  UNION ALL
  SELECT 'GWC-754854918338' AS gwc_id, 'ENGAGED' AS new_status, 'first_response_at' AS ts_field, 'mohammed.razak@gwclogistics.com' AS rep_email, 'Mohammed Razak' AS rep_name
  UNION ALL
  SELECT 'GWC-756173197524' AS gwc_id, 'QUOTED' AS new_status, 'quote_sent_at' AS ts_field, 'farooque.vala@gwclogistics.com' AS rep_email, 'Farooque Abdulkarimabdul Vala' AS rep_name
  UNION ALL
  SELECT 'GWC-757023510743' AS gwc_id, 'ENGAGED' AS new_status, 'first_response_at' AS ts_field, 'farooque.vala@gwclogistics.com' AS rep_email, 'Farooque Abdulkarimabdul Vala' AS rep_name
  UNION ALL
  SELECT 'GWC-757360549106' AS gwc_id, 'ENGAGED' AS new_status, 'first_response_at' AS ts_field, 'farooque.vala@gwclogistics.com' AS rep_email, 'Farooque Abdulkarimabdul Vala' AS rep_name
  UNION ALL
  SELECT 'GWC-757370040563' AS gwc_id, 'QUOTED' AS new_status, 'quote_sent_at' AS ts_field, 'mohammed.rizwan@gwclogistics.com' AS rep_email, 'Mohammed Rizwan' AS rep_name
  UNION ALL
  SELECT 'GWC-757373418719' AS gwc_id, 'QUOTED' AS new_status, 'quote_sent_at' AS ts_field, 'farooque.vala@gwclogistics.com' AS rep_email, 'Farooque Abdulkarimabdul Vala' AS rep_name
  UNION ALL
  SELECT 'GWC-757541267661' AS gwc_id, 'ENGAGED' AS new_status, 'first_response_at' AS ts_field, 'farooque.vala@gwclogistics.com' AS rep_email, 'Farooque Abdulkarimabdul Vala' AS rep_name
  UNION ALL
  SELECT 'GWC-757550536919' AS gwc_id, 'ENGAGED' AS new_status, 'first_response_at' AS ts_field, 'farooque.vala@gwclogistics.com' AS rep_email, 'Farooque Abdulkarimabdul Vala' AS rep_name
  UNION ALL
  SELECT 'GWC-758453612792' AS gwc_id, 'ENGAGED' AS new_status, 'first_response_at' AS ts_field, 'farooque.vala@gwclogistics.com' AS rep_email, 'Farooque Abdulkarimabdul Vala' AS rep_name
  UNION ALL
  SELECT 'GWC-758457769156' AS gwc_id, 'ENGAGED' AS new_status, 'first_response_at' AS ts_field, 'farooque.vala@gwclogistics.com' AS rep_email, 'Farooque Abdulkarimabdul Vala' AS rep_name
  UNION ALL
  SELECT 'GWC-758514783461' AS gwc_id, 'ENGAGED' AS new_status, 'first_response_at' AS ts_field, 'farooque.vala@gwclogistics.com' AS rep_email, 'Farooque Abdulkarimabdul Vala' AS rep_name
  UNION ALL
  SELECT 'GWC-758839436512' AS gwc_id, 'ENGAGED' AS new_status, 'first_response_at' AS ts_field, 'farooque.vala@gwclogistics.com' AS rep_email, 'Farooque Abdulkarimabdul Vala' AS rep_name
  UNION ALL
  SELECT 'GWC-758903611616' AS gwc_id, 'ENGAGED' AS new_status, 'first_response_at' AS ts_field, 'farooque.vala@gwclogistics.com' AS rep_email, 'Farooque Abdulkarimabdul Vala' AS rep_name
  UNION ALL
  SELECT 'GWC-759151909064' AS gwc_id, 'ENGAGED' AS new_status, 'first_response_at' AS ts_field, 'farooque.vala@gwclogistics.com' AS rep_email, 'Farooque Abdulkarimabdul Vala' AS rep_name
  UNION ALL
  SELECT 'GWC-759179857129' AS gwc_id, 'ENGAGED' AS new_status, 'first_response_at' AS ts_field, 'mourad.kachbouri@gwclogistics.com' AS rep_email, 'Mourad Kachbouri' AS rep_name
  UNION ALL
  SELECT 'GWC-759689038020' AS gwc_id, 'ENGAGED' AS new_status, 'first_response_at' AS ts_field, 'mohammed.razak@gwclogistics.com' AS rep_email, 'Mohammed Razak' AS rep_name
  UNION ALL
  SELECT 'GWC-760593515766' AS gwc_id, 'ENGAGED' AS new_status, 'first_response_at' AS ts_field, 'mirza.baig@gwclogistics.com' AS rep_email, 'Mirza Ibad Baig' AS rep_name
  UNION ALL
  SELECT 'GWC-760905446625' AS gwc_id, 'ENGAGED' AS new_status, 'first_response_at' AS ts_field, 'mohammed.razak@gwclogistics.com' AS rep_email, 'Mohammed Razak' AS rep_name
  UNION ALL
  SELECT 'GWC-761040871613' AS gwc_id, 'ENGAGED' AS new_status, 'first_response_at' AS ts_field, 'farooque.vala@gwclogistics.com' AS rep_email, 'Farooque Abdulkarimabdul Vala' AS rep_name
  UNION ALL
  SELECT 'GWC-761325693138' AS gwc_id, 'ENGAGED' AS new_status, 'first_response_at' AS ts_field, 'mohammed.razak@gwclogistics.com' AS rep_email, 'Mohammed Razak' AS rep_name
  UNION ALL
  SELECT 'GWC-761532034294' AS gwc_id, 'ENGAGED' AS new_status, 'first_response_at' AS ts_field, 'mubashar.ahmad@gwclogistics.com' AS rep_email, 'Mubashar Nazir Ahmad' AS rep_name
  UNION ALL
  SELECT 'GWC-761574957246' AS gwc_id, 'ENGAGED' AS new_status, 'first_response_at' AS ts_field, 'mohammed.razak@gwclogistics.com' AS rep_email, 'Mohammed Razak' AS rep_name
  UNION ALL
  SELECT 'GWC-761877031123' AS gwc_id, 'ENGAGED' AS new_status, 'first_response_at' AS ts_field, 'mohammed.razak@gwclogistics.com' AS rep_email, 'Mohammed Razak' AS rep_name
  UNION ALL
  SELECT 'GWC-762298310882' AS gwc_id, 'ENGAGED' AS new_status, 'first_response_at' AS ts_field, 'husam.shakhshir@gwclogistics.com' AS rep_email, 'Husam Ramzi Shakhshir' AS rep_name
  UNION ALL
  SELECT 'GWC-762335312104' AS gwc_id, 'ENGAGED' AS new_status, 'first_response_at' AS ts_field, 'mourad.kachbouri@gwclogistics.com' AS rep_email, 'Mourad Kachbouri' AS rep_name
  UNION ALL
  SELECT 'GWC-762433264878' AS gwc_id, 'ENGAGED' AS new_status, 'first_response_at' AS ts_field, 'mohammed.razak@gwclogistics.com' AS rep_email, 'Mohammed Razak' AS rep_name
) AS source
ON target.gwc_id = source.gwc_id
WHEN MATCHED THEN UPDATE SET
  target.current_status = source.new_status,
  target.detected_working_rep_email = source.rep_email,
  target.detected_working_rep_name  = source.rep_name,
  target.first_response_at = CASE WHEN source.ts_field = 'first_response_at' AND (target.first_response_at IS NULL OR target.first_response_at = '') THEN '2026-04-23T06:57:18Z' ELSE target.first_response_at END,
  target.quote_sent_at     = CASE WHEN source.ts_field = 'quote_sent_at'     AND (target.quote_sent_at IS NULL OR target.quote_sent_at = '')         THEN '2026-04-23T06:57:18Z' ELSE target.quote_sent_at END,
  target.follow_up_started_at = CASE WHEN source.ts_field = 'follow_up_started_at' AND (target.follow_up_started_at IS NULL OR target.follow_up_started_at = '') THEN '2026-04-23T06:57:18Z' ELSE target.follow_up_started_at END,
  target.last_email_scan_at = '2026-04-23T07:00:00Z',
  target.updated_at = '2026-04-23T07:00:00Z'